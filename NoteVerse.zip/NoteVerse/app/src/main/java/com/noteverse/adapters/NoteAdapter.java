package com.noteverse.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.noteverse.R;
import com.noteverse.models.Note;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {

    private final Context context;
    private List<Note> notes;
    private List<Note> selectedNotes = new ArrayList<>();
    private boolean isGridView = true;
    private boolean isMultiSelect = false;
    private OnNoteClickListener listener;

    private static final int[] CARD_COLORS = {
            0xFFFFF9C4, // yellow
            0xFFE8F5E9, // green
            0xFFE3F2FD, // blue
            0xFFFFE0E0, // red/pink
            0xFFF3E5F5, // purple
            0xFFE0F7FA, // cyan
            0xFFFFF3E0, // orange
            0xFFEDE7F6, // deep purple
    };

    public interface OnNoteClickListener {
        void onNoteClick(Note note);
        void onNoteLongClick(Note note, View view);
        void onSelectionChanged(int count);
    }

    public NoteAdapter(Context context, List<Note> notes) {
        this.context = context;
        this.notes = notes;
    }

    public void setListener(OnNoteClickListener listener) {
        this.listener = listener;
    }

    public void setGridView(boolean gridView) {
        this.isGridView = gridView;
        notifyDataSetChanged();
    }

    public void updateNotes(List<Note> newNotes) {
        this.notes = newNotes;
        selectedNotes.clear();
        isMultiSelect = false;
        notifyDataSetChanged();
    }

    public void setMultiSelect(boolean multiSelect) {
        this.isMultiSelect = multiSelect;
        if (!multiSelect) {
            selectedNotes.clear();
        }
        notifyDataSetChanged();
    }

    public List<Note> getSelectedNotes() {
        return new ArrayList<>(selectedNotes);
    }

    public boolean isMultiSelect() {
        return isMultiSelect;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        int layout = isGridView ? R.layout.item_note_grid : R.layout.item_note_list;
        View view = LayoutInflater.from(context).inflate(layout, parent, false);
        return new NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        Note note = notes.get(position);

        holder.tvTitle.setText(note.getTitle().isEmpty() ? "Untitled" : note.getTitle());
        holder.tvDescription.setText(note.getDescription());
        holder.tvDate.setText(formatDate(note.getUpdatedAt()));

        if (holder.tvCategory != null) {
            holder.tvCategory.setText(note.getCategory());
        }

        // Assign color based on position
        int colorIndex = position % CARD_COLORS.length;
        holder.cardView.setCardBackgroundColor(CARD_COLORS[colorIndex]);

        // Selection highlight
        if (isMultiSelect && selectedNotes.contains(note)) {
            holder.cardView.setAlpha(0.6f);
            holder.cardView.setScaleX(0.95f);
            holder.cardView.setScaleY(0.95f);
        } else {
            holder.cardView.setAlpha(1.0f);
            holder.cardView.setScaleX(1.0f);
            holder.cardView.setScaleY(1.0f);
        }

        // Animate
        holder.itemView.startAnimation(AnimationUtils.loadAnimation(context, R.anim.note_item_anim));

        holder.cardView.setOnClickListener(v -> {
            if (isMultiSelect) {
                toggleSelection(note);
            } else if (listener != null) {
                listener.onNoteClick(note);
            }
        });

        holder.cardView.setOnLongClickListener(v -> {
            if (!isMultiSelect) {
                isMultiSelect = true;
                toggleSelection(note);
            }
            if (listener != null) {
                listener.onNoteLongClick(note, v);
            }
            return true;
        });
    }

    private void toggleSelection(Note note) {
        if (selectedNotes.contains(note)) {
            selectedNotes.remove(note);
        } else {
            selectedNotes.add(note);
        }
        notifyDataSetChanged();
        if (listener != null) {
            listener.onSelectionChanged(selectedNotes.size());
        }
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    private String formatDate(long millis) {
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
        return sdf.format(new Date(millis));
    }

    static class NoteViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView tvTitle, tvDescription, tvDate, tvCategory;

        NoteViewHolder(View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.card_note);
            tvTitle = itemView.findViewById(R.id.tv_note_title);
            tvDescription = itemView.findViewById(R.id.tv_note_description);
            tvDate = itemView.findViewById(R.id.tv_note_date);
            tvCategory = itemView.findViewById(R.id.tv_note_category);
        }
    }
}
