package com.noteverse.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.noteverse.models.Note;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "noteverse.db";
    private static final int DB_VERSION = 1;

    private static final String TABLE_NOTES = "notes";
    private static final String COL_ID = "id";
    private static final String COL_TITLE = "title";
    private static final String COL_DESCRIPTION = "description";
    private static final String COL_CATEGORY = "category";
    private static final String COL_CREATED_AT = "created_at";
    private static final String COL_UPDATED_AT = "updated_at";
    private static final String COL_IS_TRASHED = "is_trashed";
    private static final String COL_TRASHED_AT = "trashed_at";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_NOTES_TABLE = "CREATE TABLE " + TABLE_NOTES + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_TITLE + " TEXT, "
                + COL_DESCRIPTION + " TEXT, "
                + COL_CATEGORY + " TEXT DEFAULT 'All', "
                + COL_CREATED_AT + " INTEGER, "
                + COL_UPDATED_AT + " INTEGER, "
                + COL_IS_TRASHED + " INTEGER DEFAULT 0, "
                + COL_TRASHED_AT + " INTEGER DEFAULT 0)";
        db.execSQL(CREATE_NOTES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTES);
        onCreate(db);
    }

    public long insertNote(Note note) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TITLE, note.getTitle());
        values.put(COL_DESCRIPTION, note.getDescription());
        values.put(COL_CATEGORY, note.getCategory());
        values.put(COL_CREATED_AT, note.getCreatedAt());
        values.put(COL_UPDATED_AT, note.getUpdatedAt());
        values.put(COL_IS_TRASHED, 0);
        values.put(COL_TRASHED_AT, 0);
        long id = db.insert(TABLE_NOTES, null, values);
        db.close();
        return id;
    }

    public void updateNote(Note note) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TITLE, note.getTitle());
        values.put(COL_DESCRIPTION, note.getDescription());
        values.put(COL_CATEGORY, note.getCategory());
        values.put(COL_UPDATED_AT, note.getUpdatedAt());
        db.update(TABLE_NOTES, values, COL_ID + "=?", new String[]{String.valueOf(note.getId())});
        db.close();
    }

    public List<Note> getAllNotes(String sortBy) {
        List<Note> notes = new ArrayList<>();
        String orderBy = COL_UPDATED_AT + " DESC";
        if ("title".equals(sortBy)) orderBy = COL_TITLE + " ASC";
        else if ("created".equals(sortBy)) orderBy = COL_CREATED_AT + " DESC";

        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_NOTES, null,
                COL_IS_TRASHED + "=0", null, null, null, orderBy);

        if (cursor.moveToFirst()) {
            do {
                notes.add(cursorToNote(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return notes;
    }

    public List<Note> getNotesByCategory(String category, String sortBy) {
        if ("All".equals(category)) return getAllNotes(sortBy);
        List<Note> notes = new ArrayList<>();
        String orderBy = COL_UPDATED_AT + " DESC";
        if ("title".equals(sortBy)) orderBy = COL_TITLE + " ASC";

        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_NOTES, null,
                COL_IS_TRASHED + "=0 AND " + COL_CATEGORY + "=?",
                new String[]{category}, null, null, orderBy);

        if (cursor.moveToFirst()) {
            do {
                notes.add(cursorToNote(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return notes;
    }

    public List<Note> getTrashedNotes() {
        List<Note> notes = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_NOTES, null,
                COL_IS_TRASHED + "=1", null, null, null, COL_TRASHED_AT + " DESC");

        if (cursor.moveToFirst()) {
            do {
                notes.add(cursorToNote(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return notes;
    }

    public void moveToTrash(int noteId) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_IS_TRASHED, 1);
        values.put(COL_TRASHED_AT, System.currentTimeMillis());
        db.update(TABLE_NOTES, values, COL_ID + "=?", new String[]{String.valueOf(noteId)});
        db.close();
    }

    public void restoreFromTrash(int noteId) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_IS_TRASHED, 0);
        values.put(COL_TRASHED_AT, 0);
        db.update(TABLE_NOTES, values, COL_ID + "=?", new String[]{String.valueOf(noteId)});
        db.close();
    }

    public void deletePermanently(int noteId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_NOTES, COL_ID + "=?", new String[]{String.valueOf(noteId)});
        db.close();
    }

    public void emptyTrash() {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_NOTES, COL_IS_TRASHED + "=1", null);
        db.close();
    }

    public void deleteAllNotes() {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_NOTES, null, null);
        db.close();
    }

    public List<Note> searchNotes(String query) {
        List<Note> notes = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String selection = COL_IS_TRASHED + "=0 AND (" + COL_TITLE + " LIKE ? OR " + COL_DESCRIPTION + " LIKE ?)";
        String[] selectionArgs = {"%" + query + "%", "%" + query + "%"};
        Cursor cursor = db.query(TABLE_NOTES, null, selection, selectionArgs, null, null, COL_UPDATED_AT + " DESC");

        if (cursor.moveToFirst()) {
            do {
                notes.add(cursorToNote(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return notes;
    }

    public void autoCleanTrash(int daysOld) {
        long cutoff = System.currentTimeMillis() - ((long) daysOld * 24 * 60 * 60 * 1000);
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_NOTES, COL_IS_TRASHED + "=1 AND " + COL_TRASHED_AT + "<?", new String[]{String.valueOf(cutoff)});
        db.close();
    }

    private Note cursorToNote(Cursor cursor) {
        Note note = new Note();
        note.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)));
        note.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COL_TITLE)));
        note.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(COL_DESCRIPTION)));
        note.setCategory(cursor.getString(cursor.getColumnIndexOrThrow(COL_CATEGORY)));
        note.setCreatedAt(cursor.getLong(cursor.getColumnIndexOrThrow(COL_CREATED_AT)));
        note.setUpdatedAt(cursor.getLong(cursor.getColumnIndexOrThrow(COL_UPDATED_AT)));
        note.setTrashed(cursor.getInt(cursor.getColumnIndexOrThrow(COL_IS_TRASHED)) == 1);
        return note;
    }
}
