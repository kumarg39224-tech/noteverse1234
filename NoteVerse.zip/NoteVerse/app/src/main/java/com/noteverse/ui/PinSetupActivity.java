package com.noteverse.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.noteverse.R;
import com.noteverse.database.PrefsManager;

public class PinSetupActivity extends AppCompatActivity {

    private TextView tvPinStep, tvPinDots;
    private StringBuilder pinInput = new StringBuilder();
    private String firstPin = "";
    private boolean isConfirming = false;
    private PrefsManager prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin_setup);

        prefs = PrefsManager.getInstance(this);

        tvPinStep = findViewById(R.id.tv_pin_step);
        tvPinDots = findViewById(R.id.tv_pin_dots);

        setupKeypad();
    }

    private void setupKeypad() {
        int[] numBtnIds = {R.id.btn_0, R.id.btn_1, R.id.btn_2, R.id.btn_3,
                R.id.btn_4, R.id.btn_5, R.id.btn_6, R.id.btn_7,
                R.id.btn_8, R.id.btn_9};

        for (int i = 0; i < numBtnIds.length; i++) {
            final String digit = String.valueOf(i);
            Button btn = findViewById(numBtnIds[i]);
            if (btn != null) {
                btn.setOnClickListener(v -> addDigit(digit));
            }
        }

        ImageButton btnBackspace = findViewById(R.id.btn_backspace);
        if (btnBackspace != null) {
            btnBackspace.setOnClickListener(v -> {
                if (pinInput.length() > 0) {
                    pinInput.deleteCharAt(pinInput.length() - 1);
                    updateDots();
                }
            });
        }
    }

    private void addDigit(String digit) {
        if (pinInput.length() < 4) {
            pinInput.append(digit);
            updateDots();
            if (pinInput.length() == 4) {
                processPin();
            }
        }
    }

    private void updateDots() {
        StringBuilder dots = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            if (i < pinInput.length()) dots.append("● ");
            else dots.append("○ ");
        }
        tvPinDots.setText(dots.toString().trim());
    }

    private void processPin() {
        if (!isConfirming) {
            firstPin = pinInput.toString();
            isConfirming = true;
            pinInput = new StringBuilder();
            tvPinStep.setText("Confirm your PIN");
            updateDots();
            Toast.makeText(this, "Now confirm your PIN", Toast.LENGTH_SHORT).show();
        } else {
            if (pinInput.toString().equals(firstPin)) {
                prefs.setPin(firstPin);
                prefs.setPinEnabled(true);
                Toast.makeText(this, "PIN set successfully!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "PINs don't match. Try again.", Toast.LENGTH_SHORT).show();
                isConfirming = false;
                firstPin = "";
                pinInput = new StringBuilder();
                tvPinStep.setText("Set a 4-digit PIN");
                updateDots();
            }
        }
    }
}
