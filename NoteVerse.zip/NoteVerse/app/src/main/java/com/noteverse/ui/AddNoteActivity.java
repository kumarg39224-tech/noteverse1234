package com.noteverse.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.noteverse.R;
import com.noteverse.database.DatabaseHelper;
import com.noteverse.models.Note;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddNoteActivity extends AppCompatActivity {

    private EditText etTitle, etDescription;
    private TextView tvCharCount, tvCreatedDate;
    private AutoCompleteTextView spinnerCategory;
    private DatabaseHelper db;
    private boolean isSaved = false;

    private static final String[] CATEGORIES = {"All", "Work", "Personal", "Ideas", "Shopping", "Other"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        db = DatabaseHelper.getInstance(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("New Note");
        }

        etTitle = findViewById(R.id.et_note_title);
        etDescription = findViewById(R.id.et_note_description);
        tvCharCount = findViewById(R.id.tv_char_count);
        tvCreatedDate = findViewById(R.id.tv_created_date);
        spinnerCategory = findViewById(R.id.spinner_category);

        // Setup category dropdown
        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, CATEGORIES);
        spinnerCategory.setAdapter(categoryAdapter);
        spinnerCategory.setText("All", false);

        // Created date
        String dateStr = new SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(new Date());
        tvCreatedDate.setText("Created: " + dateStr);

        // Character counter
        etDescription.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                tvCharCount.setText(s.length() + " characters");
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // Save button
        findViewById(R.id.btn_save_note).setOnClickListener(v -> saveNote());
    }

    private void saveNote() {
        String title = etTitle.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String category = spinnerCategory.getText().toString();

        if (title.isEmpty() && description.isEmpty()) {
            Toast.makeText(this, "Note is empty!", Toast.LENGTH_SHORT).show();
            return;
        }

        Note note = new Note();
        note.setTitle(title);
        note.setDescription(description);
        note.setCategory(category.isEmpty() ? "All" : category);
        long now = System.currentTimeMillis();
        note.setCreatedAt(now);
        note.setUpdatedAt(now);

        db.insertNote(note);
        isSaved = true;
        Toast.makeText(this, "Note saved!", Toast.LENGTH_SHORT).show();
        finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            if (!isSaved) {
                String title = etTitle.getText().toString().trim();
                String desc = etDescription.getText().toString().trim();
                if (!title.isEmpty() || !desc.isEmpty()) {
                    saveNote();
                    return true;
                }
            }
            finish();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        String title = etTitle.getText().toString().trim();
        String desc = etDescription.getText().toString().trim();
        if (!title.isEmpty() || !desc.isEmpty()) {
            saveNote();
        } else {
            super.onBackPressed();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        }
    }
}
