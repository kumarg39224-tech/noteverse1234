package com.noteverse.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.noteverse.R;
import com.noteverse.database.DatabaseHelper;
import com.noteverse.models.Note;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EditNoteActivity extends AppCompatActivity {

    private EditText etTitle, etDescription;
    private TextView tvCharCount, tvDates;
    private AutoCompleteTextView spinnerCategory;
    private DatabaseHelper db;
    private Note currentNote;
    private int noteId;

    private static final String[] CATEGORIES = {"All", "Work", "Personal", "Ideas", "Shopping", "Other"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_note);

        db = DatabaseHelper.getInstance(this);
        noteId = getIntent().getIntExtra("note_id", -1);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Edit Note");
        }

        etTitle = findViewById(R.id.et_note_title);
        etDescription = findViewById(R.id.et_note_description);
        tvCharCount = findViewById(R.id.tv_char_count);
        tvDates = findViewById(R.id.tv_dates);
        spinnerCategory = findViewById(R.id.spinner_category);

        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, CATEGORIES);
        spinnerCategory.setAdapter(categoryAdapter);

        etDescription.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                tvCharCount.setText(s.length() + " characters");
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        loadNote();

        findViewById(R.id.btn_save_note).setOnClickListener(v -> saveNote());
        findViewById(R.id.btn_share_note).setOnClickListener(v -> shareNote());
    }

    private void loadNote() {
        // Load note from DB
        // We'll get it from a fresh query
        java.util.List<Note> allNotes = db.getAllNotes("updated");
        for (Note n : allNotes) {
            if (n.getId() == noteId) {
                currentNote = n;
                break;
            }
        }
        // Also check trash
        if (currentNote == null) {
            java.util.List<Note> trashed = db.getTrashedNotes();
            for (Note n : trashed) {
                if (n.getId() == noteId) {
                    currentNote = n;
                    break;
                }
            }
        }

        if (currentNote == null) {
            Toast.makeText(this, "Note not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        etTitle.setText(currentNote.getTitle());
        etDescription.setText(currentNote.getDescription());
        spinnerCategory.setText(currentNote.getCategory(), false);
        tvCharCount.setText(currentNote.getDescription().length() + " characters");

        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault());
        String created = sdf.format(new Date(currentNote.getCreatedAt()));
        String updated = sdf.format(new Date(currentNote.getUpdatedAt()));
        tvDates.setText("Created: " + created + "\nUpdated: " + updated);
    }

    private void saveNote() {
        String title = etTitle.getText().toString().trim();
        String description = etDescription.getText().toString().trim();
        String category = spinnerCategory.getText().toString();

        if (currentNote == null) return;

        currentNote.setTitle(title);
        currentNote.setDescription(description);
        currentNote.setCategory(category.isEmpty() ? "All" : category);
        currentNote.setUpdatedAt(System.currentTimeMillis());

        db.updateNote(currentNote);
        Toast.makeText(this, "Note updated!", Toast.LENGTH_SHORT).show();
        finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    private void shareNote() {
        if (currentNote == null) return;
        String shareText = currentNote.getTitle() + "\n\n" + currentNote.getDescription();
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
        startActivity(Intent.createChooser(shareIntent, "Share note via"));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_edit_note, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            saveNote();
            return true;
        } else if (item.getItemId() == R.id.action_trash) {
            new AlertDialog.Builder(this)
                    .setTitle("Move to Trash?")
                    .setMessage("This note will be moved to the trash bin.")
                    .setPositiveButton("Move", (d, w) -> {
                        db.moveToTrash(noteId);
                        Toast.makeText(this, "Moved to trash", Toast.LENGTH_SHORT).show();
                        finish();
                        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        saveNote();
    }
}
