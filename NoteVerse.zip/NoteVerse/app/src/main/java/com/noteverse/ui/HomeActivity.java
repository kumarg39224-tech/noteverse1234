package com.noteverse.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.noteverse.R;
import com.noteverse.adapters.NoteAdapter;
import com.noteverse.database.DatabaseHelper;
import com.noteverse.database.PrefsManager;
import com.noteverse.models.Note;

import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private NoteAdapter adapter;
    private DatabaseHelper db;
    private PrefsManager prefs;
    private boolean isGridView = true;
    private String currentCategory = "All";
    private String currentSort = "updated";
    private ImageButton btnToggleView;
    private TextView tvNoteCount;
    private LinearLayout layoutSelectionBar;
    private TextView tvSelectedCount;

    private static final String[] CATEGORIES = {"All", "Work", "Personal", "Ideas", "Shopping", "Other"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = PrefsManager.getInstance(this);

        if (prefs.isDarkMode()) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        setContentView(R.layout.activity_home);

        db = DatabaseHelper.getInstance(this);
        isGridView = "grid".equals(prefs.getViewMode());
        currentSort = prefs.getSortBy();

        initViews();
        setupCategoryFilters();
        loadNotes();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNotes();
    }

    private void initViews() {
        recyclerView = findViewById(R.id.recycler_notes);
        btnToggleView = findViewById(R.id.btn_toggle_view);
        tvNoteCount = findViewById(R.id.tv_note_count);
        layoutSelectionBar = findViewById(R.id.layout_selection_bar);
        tvSelectedCount = findViewById(R.id.tv_selected_count);

        FloatingActionButton fab = findViewById(R.id.fab_add_note);
        fab.setOnClickListener(v -> {
            startActivity(new Intent(HomeActivity.this, AddNoteActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        ImageButton btnSearch = findViewById(R.id.btn_search);
        EditText etSearch = findViewById(R.id.et_search);

        btnSearch.setOnClickListener(v -> {
            if (etSearch.getVisibility() == View.VISIBLE) {
                etSearch.setVisibility(View.GONE);
                etSearch.setText("");
                loadNotes();
            } else {
                etSearch.setVisibility(View.VISIBLE);
                etSearch.requestFocus();
            }
        });

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    List<Note> results = db.searchNotes(s.toString());
                    adapter.updateNotes(results);
                } else {
                    loadNotes();
                }
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        btnToggleView.setOnClickListener(v -> {
            isGridView = !isGridView;
            prefs.setViewMode(isGridView ? "grid" : "list");
            updateLayoutManager();
            adapter.setGridView(isGridView);
            btnToggleView.setImageResource(isGridView ? R.drawable.ic_list : R.drawable.ic_grid);
        });

        ImageButton btnTrash = findViewById(R.id.btn_trash);
        btnTrash.setOnClickListener(v -> {
            startActivity(new Intent(HomeActivity.this, TrashActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        ImageButton btnSettings = findViewById(R.id.btn_settings);
        btnSettings.setOnClickListener(v -> {
            startActivity(new Intent(HomeActivity.this, SettingsActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        // Sort button
        ImageButton btnSort = findViewById(R.id.btn_sort);
        btnSort.setOnClickListener(v -> showSortDialog());

        // Selection bar buttons
        TextView btnDeleteSelected = findViewById(R.id.btn_delete_selected);
        btnDeleteSelected.setOnClickListener(v -> deleteSelected());

        TextView btnCancelSelect = findViewById(R.id.btn_cancel_select);
        btnCancelSelect.setOnClickListener(v -> {
            adapter.setMultiSelect(false);
            layoutSelectionBar.setVisibility(View.GONE);
        });

        // Adapter setup
        List<Note> notes = db.getNotesByCategory(currentCategory, currentSort);
        adapter = new NoteAdapter(this, notes);
        adapter.setGridView(isGridView);
        adapter.setListener(new NoteAdapter.OnNoteClickListener() {
            @Override
            public void onNoteClick(Note note) {
                Intent intent = new Intent(HomeActivity.this, EditNoteActivity.class);
                intent.putExtra("note_id", note.getId());
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }

            @Override
            public void onNoteLongClick(Note note, View view) {
                layoutSelectionBar.setVisibility(View.VISIBLE);
                showNoteOptions(note);
            }

            @Override
            public void onSelectionChanged(int count) {
                tvSelectedCount.setText(count + " selected");
                if (count == 0) {
                    adapter.setMultiSelect(false);
                    layoutSelectionBar.setVisibility(View.GONE);
                }
            }
        });

        updateLayoutManager();
        recyclerView.setAdapter(adapter);
    }

    private void updateLayoutManager() {
        if (isGridView) {
            recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        } else {
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
        }
    }

    private void setupCategoryFilters() {
        HorizontalScrollView scrollView = findViewById(R.id.scroll_categories);
        LinearLayout layout = findViewById(R.id.layout_categories);
        layout.removeAllViews();

        for (String category : CATEGORIES) {
            TextView chip = new TextView(this);
            chip.setText(category);
            chip.setPadding(40, 20, 40, 20);
            chip.setTextSize(13f);
            chip.setTextColor(getResources().getColor(R.color.text_primary, getTheme()));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(8, 0, 8, 0);
            chip.setLayoutParams(params);

            if (category.equals(currentCategory)) {
                chip.setBackgroundResource(R.drawable.bg_chip_selected);
                chip.setTextColor(getResources().getColor(android.R.color.white, getTheme()));
            } else {
                chip.setBackgroundResource(R.drawable.bg_chip_unselected);
            }

            chip.setOnClickListener(v -> {
                currentCategory = category;
                setupCategoryFilters();
                loadNotes();
            });

            layout.addView(chip);
        }
    }

    private void loadNotes() {
        if (prefs.isAutoCleanTrash()) {
            db.autoCleanTrash(prefs.getAutoCleanDays());
        }
        List<Note> notes = db.getNotesByCategory(currentCategory, currentSort);
        adapter.updateNotes(notes);
        tvNoteCount.setText(notes.size() + " notes");
    }

    private void showSortDialog() {
        String[] options = {"Last Updated", "Date Created", "Title A-Z"};
        new AlertDialog.Builder(this)
                .setTitle("Sort Notes")
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0: currentSort = "updated"; break;
                        case 1: currentSort = "created"; break;
                        case 2: currentSort = "title"; break;
                    }
                    prefs.setSortBy(currentSort);
                    loadNotes();
                }).show();
    }

    private void showNoteOptions(Note note) {
        String[] options = {"Edit", "Share", "Move to Trash"};
        new AlertDialog.Builder(this)
                .setTitle(note.getTitle().isEmpty() ? "Note Options" : note.getTitle())
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            Intent intent = new Intent(HomeActivity.this, EditNoteActivity.class);
                            intent.putExtra("note_id", note.getId());
                            startActivity(intent);
                            break;
                        case 1:
                            shareNote(note);
                            break;
                        case 2:
                            db.moveToTrash(note.getId());
                            loadNotes();
                            Toast.makeText(this, "Moved to trash", Toast.LENGTH_SHORT).show();
                            break;
                    }
                    adapter.setMultiSelect(false);
                    layoutSelectionBar.setVisibility(View.GONE);
                }).show();
    }

    private void deleteSelected() {
        List<Note> selected = adapter.getSelectedNotes();
        if (selected.isEmpty()) return;

        new AlertDialog.Builder(this)
                .setTitle("Move to Trash")
                .setMessage("Move " + selected.size() + " note(s) to trash?")
                .setPositiveButton("Move", (dialog, which) -> {
                    for (Note note : selected) {
                        db.moveToTrash(note.getId());
                    }
                    adapter.setMultiSelect(false);
                    layoutSelectionBar.setVisibility(View.GONE);
                    loadNotes();
                    Toast.makeText(this, selected.size() + " note(s) moved to trash", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void shareNote(Note note) {
        String shareText = note.getTitle() + "\n\n" + note.getDescription();
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
        startActivity(Intent.createChooser(shareIntent, "Share note via"));
    }
}
