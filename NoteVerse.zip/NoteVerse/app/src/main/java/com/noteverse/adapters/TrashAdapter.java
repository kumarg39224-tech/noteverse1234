package com.noteverse.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.noteverse.R;
import com.noteverse.models.Note;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TrashAdapter extends RecyclerView.Adapter<TrashAdapter.TrashViewHolder> {

    private final Context context;
    private List<Note> notes;
    private final List<Note> selectedNotes = new ArrayList<>();
    private boolean isMultiSelect = false;
    private OnTrashNoteListener listener;

    public interface OnTrashNoteListener {
        void onRestoreClick(Note note);
        void onDeleteClick(Note note);
        void onSelectionChanged(int count);
    }

    public TrashAdapter(Context context, List<Note> notes) {
        this.context = context;
        this.notes = notes;
    }

    public void setListener(OnTrashNoteListener listener) {
        this.listener = listener;
    }

    public void updateNotes(List<Note> newNotes) {
        this.notes = newNotes;
        selectedNotes.clear();
        notifyDataSetChanged();
    }

    public void setMultiSelect(boolean multiSelect) {
        this.isMultiSelect = multiSelect;
        if (!multiSelect) selectedNotes.clear();
        notifyDataSetChanged();
    }

    public List<Note> getSelectedNotes() {
        return new ArrayList<>(selectedNotes);
    }

    @NonNull
    @Override
    public TrashViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_trash_note, parent, false);
        return new TrashViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TrashViewHolder holder, int position) {
        Note note = notes.get(position);
        holder.tvTitle.setText(note.getTitle().isEmpty() ? "Untitled" : note.getTitle());
        holder.tvDescription.setText(note.getDescription());
        holder.tvDate.setText("Deleted: " + formatDate(note.getUpdatedAt()));

        holder.checkBox.setVisibility(isMultiSelect ? View.VISIBLE : View.GONE);
        holder.checkBox.setChecked(selectedNotes.contains(note));

        holder.btnRestore.setOnClickListener(v -> {
            if (listener != null) listener.onRestoreClick(note);
        });

        holder.btnDelete.setOnClickListener(v -> {
            if (listener != null) listener.onDeleteClick(note);
        });

        holder.cardView.setOnLongClickListener(v -> {
            isMultiSelect = true;
            toggleSelection(note);
            return true;
        });

        holder.cardView.setOnClickListener(v -> {
            if (isMultiSelect) toggleSelection(note);
        });
    }

    private void toggleSelection(Note note) {
        if (selectedNotes.contains(note)) {
            selectedNotes.remove(note);
        } else {
            selectedNotes.add(note);
        }
        notifyDataSetChanged();
        if (listener != null) listener.onSelectionChanged(selectedNotes.size());
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    private String formatDate(long millis) {
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
        return sdf.format(new Date(millis));
    }

    static class TrashViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView tvTitle, tvDescription, tvDate, btnRestore, btnDelete;
        CheckBox checkBox;

        TrashViewHolder(View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.card_trash_note);
            tvTitle = itemView.findViewById(R.id.tv_trash_title);
            tvDescription = itemView.findViewById(R.id.tv_trash_description);
            tvDate = itemView.findViewById(R.id.tv_trash_date);
            btnRestore = itemView.findViewById(R.id.btn_restore);
            btnDelete = itemView.findViewById(R.id.btn_delete_perm);
            checkBox = itemView.findViewById(R.id.checkbox_select);
        }
    }
}
