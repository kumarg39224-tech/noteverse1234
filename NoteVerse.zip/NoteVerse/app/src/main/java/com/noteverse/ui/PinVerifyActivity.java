package com.noteverse.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.noteverse.R;
import com.noteverse.database.PrefsManager;
import com.noteverse.ui.HomeActivity;

public class PinVerifyActivity extends AppCompatActivity {

    private TextView tvPinDots;
    private StringBuilder pinInput = new StringBuilder();
    private PrefsManager prefs;
    private int attempts = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin_verify);

        prefs = PrefsManager.getInstance(this);
        tvPinDots = findViewById(R.id.tv_pin_dots);

        setupKeypad();

        TextView tvForgotPin = findViewById(R.id.tv_forgot_pin);
        tvForgotPin.setOnClickListener(v -> showForgotPinDialog());
    }

    private void setupKeypad() {
        int[] numBtnIds = {R.id.btn_0, R.id.btn_1, R.id.btn_2, R.id.btn_3,
                R.id.btn_4, R.id.btn_5, R.id.btn_6, R.id.btn_7,
                R.id.btn_8, R.id.btn_9};

        for (int i = 0; i < numBtnIds.length; i++) {
            final String digit = String.valueOf(i);
            Button btn = findViewById(numBtnIds[i]);
            if (btn != null) {
                btn.setOnClickListener(v -> addDigit(digit));
            }
        }

        ImageButton btnBackspace = findViewById(R.id.btn_backspace);
        if (btnBackspace != null) {
            btnBackspace.setOnClickListener(v -> {
                if (pinInput.length() > 0) {
                    pinInput.deleteCharAt(pinInput.length() - 1);
                    updateDots();
                }
            });
        }
    }

    private void addDigit(String digit) {
        if (pinInput.length() < 4) {
            pinInput.append(digit);
            updateDots();
            if (pinInput.length() == 4) {
                verifyPin();
            }
        }
    }

    private void updateDots() {
        StringBuilder dots = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            if (i < pinInput.length()) dots.append("● ");
            else dots.append("○ ");
        }
        tvPinDots.setText(dots.toString().trim());
    }

    private void verifyPin() {
        String savedPin = prefs.getPin();
        if (pinInput.toString().equals(savedPin)) {
            startActivity(new Intent(this, HomeActivity.class));
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            finish();
        } else {
            attempts++;
            pinInput = new StringBuilder();
            updateDots();
            if (attempts >= 3) {
                Toast.makeText(this, "Too many wrong attempts!", Toast.LENGTH_LONG).show();
                attempts = 0;
            } else {
                Toast.makeText(this, "Wrong PIN. " + (3 - attempts) + " attempts left.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showForgotPinDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Forgot PIN?")
                .setMessage("Resetting your PIN will remove PIN protection. Continue?")
                .setPositiveButton("Reset PIN", (d, w) -> {
                    prefs.setPin("");
                    prefs.setPinEnabled(false);
                    Toast.makeText(this, "PIN removed. You can set a new PIN in Settings.", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(this, HomeActivity.class));
                    finish();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onBackPressed() {
        // Disable back button on PIN screen
    }
}
