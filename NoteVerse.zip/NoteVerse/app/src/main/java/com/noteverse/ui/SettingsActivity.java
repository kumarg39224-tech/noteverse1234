package com.noteverse.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;

import com.noteverse.R;
import com.noteverse.database.DatabaseHelper;
import com.noteverse.database.PrefsManager;

public class SettingsActivity extends AppCompatActivity {

    private PrefsManager prefs;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefs = PrefsManager.getInstance(this);
        db = DatabaseHelper.getInstance(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Settings");
        }

        // Dark Mode Toggle
        Switch switchDarkMode = findViewById(R.id.switch_dark_mode);
        switchDarkMode.setChecked(prefs.isDarkMode());
        switchDarkMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.setDarkMode(isChecked);
            AppCompatDelegate.setDefaultNightMode(isChecked ?
                    AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
            recreate();
        });

        // PIN Lock Toggle
        Switch switchPin = findViewById(R.id.switch_pin_lock);
        switchPin.setChecked(prefs.isPinEnabled());
        switchPin.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                startActivity(new Intent(this, PinSetupActivity.class));
            } else {
                prefs.setPinEnabled(false);
                prefs.setPin("");
                Toast.makeText(this, "PIN lock disabled", Toast.LENGTH_SHORT).show();
            }
        });

        // Change PIN
        LinearLayout btnChangePin = findViewById(R.id.btn_change_pin);
        btnChangePin.setOnClickListener(v -> {
            if (prefs.isPinEnabled()) {
                startActivity(new Intent(this, PinSetupActivity.class));
            } else {
                Toast.makeText(this, "Enable PIN first", Toast.LENGTH_SHORT).show();
            }
        });

        // Auto-clean trash
        Switch switchAutoClean = findViewById(R.id.switch_auto_clean);
        switchAutoClean.setChecked(prefs.isAutoCleanTrash());
        switchAutoClean.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.setAutoCleanTrash(isChecked);
            Toast.makeText(this, isChecked ? "Auto-clean enabled (30 days)" : "Auto-clean disabled", Toast.LENGTH_SHORT).show();
        });

        // Delete all notes
        LinearLayout btnDeleteAll = findViewById(R.id.btn_delete_all_notes);
        btnDeleteAll.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Delete All Notes?")
                    .setMessage("This will permanently delete ALL notes including trash. This cannot be undone!")
                    .setPositiveButton("Delete All", (d, w) -> {
                        db.deleteAllNotes();
                        Toast.makeText(this, "All notes deleted", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // About
        LinearLayout btnAbout = findViewById(R.id.btn_about);
        btnAbout.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("About NoteVerse")
                    .setMessage("NoteVerse v1.0\n\nPremium Notes App\n\nFeatures:\n• Offline SQLite storage\n• PIN Lock security\n• Dark & Light themes\n• Trash bin system\n• Category organization\n\nBuilt with Native Android")
                    .setPositiveButton("OK", null)
                    .show();
        });

        // App version
        TextView tvVersion = findViewById(R.id.tv_version);
        tvVersion.setText("NoteVerse v1.0");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Switch switchPin = findViewById(R.id.switch_pin_lock);
        if (switchPin != null) {
            switchPin.setChecked(prefs.isPinEnabled());
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        return true;
    }
}
