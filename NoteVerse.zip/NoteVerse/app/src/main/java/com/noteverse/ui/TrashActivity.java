package com.noteverse.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.noteverse.R;
import com.noteverse.adapters.TrashAdapter;
import com.noteverse.database.DatabaseHelper;
import com.noteverse.models.Note;

import java.util.List;

public class TrashActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TrashAdapter adapter;
    private DatabaseHelper db;
    private TextView tvEmptyTrash;
    private LinearLayout layoutSelectionBar;
    private TextView tvSelectedCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trash);

        db = DatabaseHelper.getInstance(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Trash");
        }

        recyclerView = findViewById(R.id.recycler_trash);
        tvEmptyTrash = findViewById(R.id.tv_empty_trash);
        layoutSelectionBar = findViewById(R.id.layout_selection_bar);
        tvSelectedCount = findViewById(R.id.tv_selected_count);

        List<Note> trashedNotes = db.getTrashedNotes();
        adapter = new TrashAdapter(this, trashedNotes);
        adapter.setListener(new TrashAdapter.OnTrashNoteListener() {
            @Override
            public void onRestoreClick(Note note) {
                db.restoreFromTrash(note.getId());
                loadTrash();
                Toast.makeText(TrashActivity.this, "Note restored!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onDeleteClick(Note note) {
                new AlertDialog.Builder(TrashActivity.this)
                        .setTitle("Delete Permanently?")
                        .setMessage("This note cannot be recovered after deletion.")
                        .setPositiveButton("Delete", (d, w) -> {
                            db.deletePermanently(note.getId());
                            loadTrash();
                            Toast.makeText(TrashActivity.this, "Note deleted", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }

            @Override
            public void onSelectionChanged(int count) {
                tvSelectedCount.setText(count + " selected");
                layoutSelectionBar.setVisibility(count > 0 ? View.VISIBLE : View.GONE);
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Empty trash button
        findViewById(R.id.btn_empty_trash).setOnClickListener(v -> {
            if (db.getTrashedNotes().isEmpty()) {
                Toast.makeText(this, "Trash is already empty", Toast.LENGTH_SHORT).show();
                return;
            }
            new AlertDialog.Builder(this)
                    .setTitle("Empty Trash?")
                    .setMessage("All notes in trash will be permanently deleted.")
                    .setPositiveButton("Empty Trash", (d, w) -> {
                        db.emptyTrash();
                        loadTrash();
                        Toast.makeText(this, "Trash emptied", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // Delete selected
        TextView btnDeleteSelected = findViewById(R.id.btn_delete_selected);
        btnDeleteSelected.setOnClickListener(v -> {
            List<Note> selected = adapter.getSelectedNotes();
            if (selected.isEmpty()) return;
            new AlertDialog.Builder(this)
                    .setTitle("Delete Permanently?")
                    .setMessage("Delete " + selected.size() + " note(s) permanently?")
                    .setPositiveButton("Delete", (d, w) -> {
                        for (Note note : selected) {
                            db.deletePermanently(note.getId());
                        }
                        adapter.setMultiSelect(false);
                        layoutSelectionBar.setVisibility(View.GONE);
                        loadTrash();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // Restore selected
        TextView btnRestoreSelected = findViewById(R.id.btn_restore_selected);
        btnRestoreSelected.setOnClickListener(v -> {
            List<Note> selected = adapter.getSelectedNotes();
            for (Note note : selected) {
                db.restoreFromTrash(note.getId());
            }
            adapter.setMultiSelect(false);
            layoutSelectionBar.setVisibility(View.GONE);
            loadTrash();
            Toast.makeText(this, selected.size() + " note(s) restored", Toast.LENGTH_SHORT).show();
        });

        loadTrash();
    }

    private void loadTrash() {
        List<Note> notes = db.getTrashedNotes();
        adapter.updateNotes(notes);
        tvEmptyTrash.setVisibility(notes.isEmpty() ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(notes.isEmpty() ? View.GONE : View.VISIBLE);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        return true;
    }
}
