package com.noteverse.database;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefsManager {
    private static final String PREFS_NAME = "noteverse_prefs";
    private static final String KEY_PIN = "user_pin";
    private static final String KEY_PIN_ENABLED = "pin_enabled";
    private static final String KEY_DARK_MODE = "dark_mode";
    private static final String KEY_SORT_BY = "sort_by";
    private static final String KEY_VIEW_MODE = "view_mode";
    private static final String KEY_AUTO_CLEAN_TRASH = "auto_clean_trash";
    private static final String KEY_AUTO_CLEAN_DAYS = "auto_clean_days";

    private static PrefsManager instance;
    private final SharedPreferences prefs;

    public static synchronized PrefsManager getInstance(Context context) {
        if (instance == null) {
            instance = new PrefsManager(context.getApplicationContext());
        }
        return instance;
    }

    private PrefsManager(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void setPin(String pin) {
        prefs.edit().putString(KEY_PIN, pin).apply();
    }

    public String getPin() {
        return prefs.getString(KEY_PIN, "");
    }

    public void setPinEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_PIN_ENABLED, enabled).apply();
    }

    public boolean isPinEnabled() {
        return prefs.getBoolean(KEY_PIN_ENABLED, false);
    }

    public void setDarkMode(boolean dark) {
        prefs.edit().putBoolean(KEY_DARK_MODE, dark).apply();
    }

    public boolean isDarkMode() {
        return prefs.getBoolean(KEY_DARK_MODE, false);
    }

    public void setSortBy(String sortBy) {
        prefs.edit().putString(KEY_SORT_BY, sortBy).apply();
    }

    public String getSortBy() {
        return prefs.getString(KEY_SORT_BY, "updated");
    }

    public void setViewMode(String mode) {
        prefs.edit().putString(KEY_VIEW_MODE, mode).apply();
    }

    public String getViewMode() {
        return prefs.getString(KEY_VIEW_MODE, "grid");
    }

    public void setAutoCleanTrash(boolean enabled) {
        prefs.edit().putBoolean(KEY_AUTO_CLEAN_TRASH, enabled).apply();
    }

    public boolean isAutoCleanTrash() {
        return prefs.getBoolean(KEY_AUTO_CLEAN_TRASH, false);
    }

    public void setAutoCleanDays(int days) {
        prefs.edit().putInt(KEY_AUTO_CLEAN_DAYS, days).apply();
    }

    public int getAutoCleanDays() {
        return prefs.getInt(KEY_AUTO_CLEAN_DAYS, 30);
    }
}
